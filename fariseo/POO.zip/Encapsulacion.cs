﻿using System;
using Alumno = Actividad_1.Alumno;
using Abonado = Actividad_2.Abonado;
using Legajo = Actividad_3.Legajo;
class Program
{
    static void Main()
    {
        Alumno alumno1 = new Alumno("Perez", "Juan", 20, 12345678);
        Alumno alumno2 = new Alumno("Gomez", "Maria", 22, 87654321);
        Alumno alumno3 = new Alumno("Lopez", "Carlos", 19, 11223344);
        Alumno alumno4 = new Alumno("Rodriguez", "Ana", 21, 55667788);
        Alumno alumno5 = new Alumno("Garcia", "Lucia", 23, 99887766);
        //6 Sanchez Lucia 20 390001111
        //7 Diaz Pedro 23 320002222
        //8 Torres Sofia 19 410003333
        //9 Ruiz Diego 21 360004444
        //10 Flores Elena 20 380005555
        Alumno alumno6 = new Alumno();
        Alumno alumno7 = new Alumno();
        Alumno alumno8 = new Alumno();
        Alumno alumno9 = new Alumno();
        Alumno alumno10 = new Alumno();
        alumno6.Apellido="Sanchez";
        alumno6.Nombre="Lucia";
        alumno6.Edad=20;
        alumno6.Dni=390001111;
        alumno7.Apellido="Ruiz";
        alumno7.Nombre="Diego";
        alumno7.Edad=21;
        alumno7.Dni=360004444;
        alumno8.Apellido="Flores";
        alumno8.Nombre="Elena";
        alumno8.Edad=20;
        alumno8.Dni=380005555;
        alumno9.Apellido="Sanchez";
        alumno9.Nombre="Lucia";
        alumno9.Edad=20;
        alumno9.Dni=390001111;
        alumno10.Apellido="Diaz";
        alumno10.Nombre="Pedro";
        alumno10.Edad=23;
        alumno10.Dni=320002222;

        /*
        ■ Generar una lista de Legajos.
        ■ Crear un pequeño menú que permita: ingresar un Legajo y mostrar todos los Legajos.
        */
        List<Legajo> legajos = new List<Legajo>();
        string opcion;
        do
        {
            Console.WriteLine("Menú:");
            Console.WriteLine("1. Ingresar un Legajo");
            Console.WriteLine("2. Mostrar todos los Legajos");
            Console.WriteLine("3. Salir");
            Console.Write("Ingrese una opción: ");
            opcion = Console.ReadLine();
            switch (opcion)
            {
                case "1":
                    Console.Write("Ingrese el DNI: ");
                    long dni = long.Parse(Console.ReadLine());
                    Console.Write("Ingrese el Nombre: ");
                    string nombre = Console.ReadLine();
                    Console.Write("Ingrese el Apellido: ");
                    string apellido = Console.ReadLine();
                    Legajo legajo = new Legajo(dni, nombre, apellido);
                    legajos.Add(legajo);
                    Console.WriteLine("Legajo ingresado correctamente.");
                    break;
                case "2":
                    Console.WriteLine("Lista de Legajos:");
                    foreach (Legajo l in legajos)
                    {
                        l.Presentar();
                    }
                    break;
                case "3":
                    Console.WriteLine("Saliendo del programa...");
                    break;
                default:
                    Console.WriteLine("Opción inválida. Intente nuevamente.");
                    break;
            }   
            
        }
        while(opcion!="3");

    }
}
namespace Actividad_1
{
public class Alumno
{
    public string Apellido{get;set;}
    public string Nombre{get;set;}
    public int Edad
    {
        get;
        set
        {
         if (value < 0)
         {
            Console.WriteLine("La edad no puede ser negativa. Se asignará 0 por defecto.");
            field = 0;
         }
         else
         {
            field = value;
         }
        }
    }
    public long Dni{get;set;}

    public int Id {get;set;}
    public static int UltimoId=0;

    public Alumno(string apellido, string nombre, int edad, long dni)
    {
        this.Apellido = apellido;
        this.Nombre = nombre;
        this.Edad = edad;
        this.Dni = dni;
        this.Id = ++UltimoId;
    }
    public Alumno()
    {
        this.Apellido="";
        this.Nombre=""; 
        this.Edad=0;
        this.Dni=0;
        this.Id = ++UltimoId;
    }
    public void Saludar()
    {
        Console.WriteLine($"Hola, soy {Nombre} {Apellido}, tengo {Edad} años y mi DNI es {Dni}");
    }
    public string DevolverApellido(long dni)
    {
        if (Dni == this.Dni) 
        return this.Apellido;
        return "";
    }
}
}
namespace Actividad_2
{
    /*
    ■ La clase debe ser pública si va a ser instanciada desde el Main.
    ■ Copiar y ejecutar el código de la clase Abonado con atributos private.
    ■ Intentar cambiar el atributo directamente desde el Main: Camilo.Id = 9; — observar el error de
    accesibilidad.
    ■ Modificar el atributo usando el método intermediario SetId(int Id).
    ■ Comprender que a través de métodos intermedios (getters/setters) se puede administrar el acceso de
    lectura y escritura.
    */
    
    public class Abonado
    {
        private int Id;
        
        private string Tarjeta{get;set;}
    public Abonado(){}
    public Abonado(int Id, string Tarjeta) 
    {
    this.Id=Id;
    this.Tarjeta=Tarjeta;
    }
    public void SetId(int Id) 
    {
    this.Id=Id; // Setter manual
    }
    public void MostrarDato() 
    {
        Console.WriteLine($"{Id} {Tarjeta}");
    }

    }

}
namespace Actividad_3
{
    /*
    ■ Generar una clase pública Legajo que contenga: Dni, Nombre y Apellido.
    ■ Con sus dos constructores: parametrizado y por defecto.
    ■ Debe tener el método Presentar que imprima sus atributos (se usará en el foreach).
    */
    public class Legajo
    {
        public long Dni{get;set;}
        public string Nombre{get;set;}
        public string Apellido{get;set;}

        public Legajo(long dni, string nombre, string apellido)
        {
            this.Dni=dni;
            this.Nombre=nombre;
            this.Apellido=apellido;
        }
        public Legajo()
        {
            this.Dni=0;
            this.Nombre="";
            this.Apellido="";
        }
        public void Presentar()
        {
            Console.WriteLine($"DNI: {Dni}, Nombre: {Nombre}, Apellido: {Apellido}");
        }
    }
}
