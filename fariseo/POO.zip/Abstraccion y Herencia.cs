﻿using Empleado = Actividad_1.Empleado;
using Vendedor = Actividad_2.Vendedor;
using Gerente = Actividad_3.Gerente;
class Program
    {
        static void Main()
        {
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("Actividad 1: Vendedores");
            Console.WriteLine();
            /*
            Generar 5 objetos parametrizados (IDs del 1 al 5), usando los datos de la tabla.
            Generar 5 objetos en blanco y completar cada uno con los datos de la tabla usando los setters (IDs
            del 6 al 10).
            Todos los objetos deben llamar a Presentarse() y a AumentarSueldo(10), simulando un aumento
            del 10%.
            ID Apellido Nombre Legajo Sueldo
            1 Fernandez Lucas 1001 350000
            2 Ibarra Marina 1002 400000
            3 Acosta Tomas 1003 320000
            4 Romero Valentina 1004 410000
            5 Suarez Bruno 1005 365000
            6 Molina Camila 1006 390000
            7 Ortega Federico 1007 370000
            8 Vega Agustina 1008 420000
            9 Paz Nicolas 1009 330000
            10 Cabrera Julieta 1010 380000
            */

            Empleado empleado1 = new Empleado("Fernandez", "Lucas", 30, 1001, 350000);
            Empleado empleado2 = new Empleado("Ibarra", "Marina", 28, 1002, 400000);
            Empleado empleado3 = new Empleado("Acosta", "Tomas", 35, 1003, 320000);
            Empleado empleado4 = new Empleado("Romero", "Valentina", 32, 1004, 410000);
            Empleado empleado5 = new Empleado("Suarez", "Bruno", 29, 1005, 365000);
            Empleado empleado6 = new Empleado();
            Empleado empleado7 = new Empleado();
            Empleado empleado8 = new Empleado();
            Empleado empleado9 = new Empleado();
            Empleado empleado10 = new Empleado();
            empleado6.Apellido="Molina";
            empleado6.Nombre="Camila";
            empleado6.Edad=27;
            empleado6.Legajo=1006;                                                  
            empleado6.Sueldo=390000;
            empleado7.Apellido="Ortega";
            empleado7.Nombre="Federico";
            empleado7.Edad=31;
            empleado7.Legajo=1007;
            empleado7.Sueldo=370000;
            empleado8.Apellido="Vega";
            empleado8.Nombre="Agustina";
            empleado8.Edad=26;
            empleado8.Legajo=1008;
            empleado8.Sueldo=420000;
            empleado9.Apellido="Paz";
            empleado9.Nombre="Nicolas";
            empleado9.Edad=33;
            empleado9.Legajo=1009;
            empleado9.Sueldo=330000;
            empleado10.Apellido="Cabrera";
            empleado10.Nombre="Julieta";
            empleado10.Edad=25;
            empleado10.Legajo=1010;
            empleado10.Sueldo=380000;

            empleado1.Presentarse();
            empleado1.AumentarSueldo(10);
            empleado2.Presentarse();
            empleado2.AumentarSueldo(10);
            empleado3.Presentarse();
            empleado3.AumentarSueldo(10);
            empleado4.Presentarse();
            empleado4.AumentarSueldo(10);
            empleado5.Presentarse();
            empleado5.AumentarSueldo(10);
            empleado6.Presentarse();
            empleado6.AumentarSueldo(10);
            empleado7.Presentarse();
            empleado7.AumentarSueldo(10);
            empleado8.Presentarse();
            empleado8.AumentarSueldo(10);
            empleado9.Presentarse();
            empleado9.AumentarSueldo(10);
            empleado10.Presentarse();
            empleado10.AumentarSueldo(10);

            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("Actividad 2: Vendedores");
            Console.WriteLine();
            /*
            Crear 3 objetos Vendedor (con datos a elección) 
            y, para cada uno, llamar a Presentarse() — heredado de Empleado— y a CalcularComisionVenta(), 
            mostrando el resultado por consola.
            */

            Vendedor vendedor1 = new Vendedor("Gomez", "Sofia", 29, 1011, 400000, 5);
            Vendedor vendedor2 = new Vendedor("Martinez", "Diego", 34, 1012, 450000, 7);
            Vendedor vendedor3 = new Vendedor("Fernandez", "Valentina", 27, 1013, 420000, 6);   

            vendedor1.Presentarse();
            long comision1 = vendedor1.CalculaComisionVenta(100000);
            Console.WriteLine($"Comisión de {vendedor1.Nombre} {vendedor1.Apellido}: {comision1}");
            
            vendedor2.Presentarse();
            long comision2 = vendedor2.CalculaComisionVenta(150000);
            Console.WriteLine($"Comisión de {vendedor2.Nombre} {vendedor2.Apellido}: {comision2}");
            
            vendedor3.Presentarse();
            long comision3 = vendedor3.CalculaComisionVenta(200000);
            Console.WriteLine($"Comisión de {vendedor3.Nombre} {vendedor3.Apellido}: {comision3}");

            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("Actividad 3: Gerentes");
            Console.WriteLine();
            /*
            Crear 2 objetos Gerente y, para cada uno, llamar a Presentarse() —heredado— 
            y a MostrarArea()—propio.
            */

            Gerente gerente1 = new Gerente("Lopez", "Javier", 40, 1014, 600000, "Ventas");
            Gerente gerente2 = new Gerente("Gonzalez", "Carla", 38, 1015, 650000, "Marketing");

            gerente1.Presentarse();
            gerente1.MostrarArea();

            gerente2.Presentarse();
            gerente2.MostrarArea();

            
            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("Actividad 4: Lista y menu");
            Console.WriteLine();

            /*
            Generar una List<Empleado> que pueda guardar tanto objetos Empleado como objetos Vendedor
            y Gerente. Dato curioso: una clase derivada «es también» un objeto de su clase base, por eso
            entra en la misma lista.
            Cargar la lista con los objetos creados en las Actividades 1, 2 y 3.
            Armar un pequeño menú por consola que permita: 1) Mostrar todos los empleados, recorriendo la
            lista con un foreach y llamando a Presentarse() de cada uno; 2) Salir.
            */

            List<Empleado> listaEmpleados = new List<Empleado>();
            listaEmpleados.Add(empleado1);
            listaEmpleados.Add(empleado2);
            listaEmpleados.Add(empleado3);
            listaEmpleados.Add(empleado4);
            listaEmpleados.Add(empleado5);
            listaEmpleados.Add(empleado6);
            listaEmpleados.Add(empleado7);
            listaEmpleados.Add(empleado8);
            listaEmpleados.Add(empleado9);
            listaEmpleados.Add(empleado10);
            listaEmpleados.Add(vendedor1);
            listaEmpleados.Add(vendedor2);
            listaEmpleados.Add(vendedor3);
            listaEmpleados.Add(gerente1);
            listaEmpleados.Add(gerente2);
            string opcion;
            do
            {
                Console.WriteLine("1) Mostrar todos los empleados");
                Console.WriteLine("2) Salir");
                opcion = Console.ReadLine() ?? "";

                switch (opcion)
                {
                    case "1":
                        foreach (Empleado empleado in listaEmpleados)
                        {
                            empleado.Presentarse();
                        }
                        break;
                    default:
                        Console.WriteLine("Opción inválida. Intente nuevamente.");
                        break;
                }
            }
            while(opcion != "2");
            Console.WriteLine("Saliendo del programa...");

            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("Actividad 5: Abstracción y Herencia");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine
            (@"
            Abstracción:
            - Clase base: Actividad_1.Empleado.
            - Atributos incluidos en Empleado: Apellido, Nombre, Edad, Legajo, Sueldo, Id.
            - Se dejaron afuera datos del mundo real como dirección, teléfono/email, fecha de ingreso,
              cargo específico, horario, antigüedad o historial detallado de ventas.

            Herencia:
            - Clase base: Empleado.
            - Clases derivadas: Actividad_2.Vendedor y Actividad_3.Gerente.

            Métodos heredados sin volver a escribirlos:
            - Presentarse()
            - AumentarSueldo(long porcentaje)

            Métodos propios de cada clase derivada:
            - Vendedor: CalculaComisionVenta(long MontoVenta)
            - Gerente: MostrarArea()
            ");
            
            





        }
    }   
namespace Actividad_1
{
 public class Empleado
    {
        public string Apellido{get;set;}
        public string Nombre{get;set;}
        public int Edad
        {
            get;
            set
            {
             if (value < 0)
             {
                Console.WriteLine("La edad no puede ser negativa. Se asignará 0 por defecto.");
                field = 0;
             }
             else
             {
                field = value;
             }
            }
        }
        public int Legajo{get;set;}
        public long Sueldo{get;set;}
        public int Id {get;set;}
        public static int UltimoId=0;
        public Empleado(string apellido, string nombre, int edad, int legajo, long sueldo)
        {
            this.Apellido = apellido;
            this.Nombre = nombre;
            this.Edad = edad;
            this.Legajo = legajo;
            this.Sueldo = sueldo;
            this.Id = ++UltimoId;
        }
        public Empleado()
        {
            this.Apellido="";
            this.Nombre="";
            this.Edad=0;
            this.Legajo=0;
            this.Sueldo=0;
            this.Id = ++UltimoId;
        }

        public void Presentarse()
        {
            Console.WriteLine($"Hola, soy {Nombre} {Apellido}, tengo {Edad} años, mi legajo es {Legajo} y mi sueldo es {Sueldo}");
        }
        public long AumentarSueldo(long porcentaje)
        {
            if (porcentaje < 0)
            {
                Console.WriteLine("El porcentaje no puede ser negativo.");
                return Sueldo;
            }
            else
            {
                Sueldo += Sueldo * porcentaje / 100;
                return Sueldo;
            }
        }
    }   
}
namespace Actividad_2
{
    class Vendedor : Empleado
    {
        public long Comsion{get;set;}
        public Vendedor(string apellido, string nombre, int edad, int legajo, long sueldo, long comision) : base(apellido, nombre, edad, legajo, sueldo)
        {
            this.Comsion = comision;
        }
        public Vendedor() : base()
        {
            this.Comsion = 0;
        }
        public long CalculaComisionVenta(long MontoVenta)
        {
            return MontoVenta * Comsion / 100;
        }

    }
}
namespace Actividad_3
{
    class Gerente : Empleado
    {
        string Area{get;set;}
        public Gerente(string apellido, string nombre, int edad, int legajo, long sueldo, string area) : base(apellido, nombre, edad, legajo, sueldo)
        {
            this.Area = area;
        }
        public Gerente() : base()
        {
            this.Area = "";
        }
        public void MostrarArea()
        {
            Console.WriteLine("Mi area es: " + Area);
        }
    }
}